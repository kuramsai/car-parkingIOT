# CuMa


Project Description
objective

This project is about ReInnovationg an public area.I personally experienced this problem in my locality. I see people throwing garbage and unrinating in public places. This happens because that location untidy or no one to take care of it. If we could develop an app which gives 2 options. Take help from NGO's or any socail welfare organisations or from students who wish to help us to clean the area and reinnovate it by adding some paintings or planting tress. similar example: http://www.thebetterindia.com/42396/ugly-indian-250-flyovers-bangalore/ Takes information from people who need help in cleaning up the area and link it to people in 1st point.

my plans

right now due to lack of developers and time i am making it in a web application.I future wil try to make it a app based for both Ios and Android.

Future plans

Tie up with local NGO's and students who are studying in engineering and degree streams and grow our community. Rewarding the teams who give thei 100%
